import { jsx } from "react/jsx-runtime";
import CustomCommandBuilder from "./components/CustomCommandBuilder";
const CustomCommandsPage = () => {
  return /* @__PURE__ */ jsx(CustomCommandBuilder, {});
};
var stdin_default = CustomCommandsPage;
export {
  stdin_default as default
};
