import { jsx } from "react/jsx-runtime";
import SuggestionsPage from "./page";
function SuggestionsPageWrapper() {
  return /* @__PURE__ */ jsx(SuggestionsPage, {});
}
var stdin_default = SuggestionsPageWrapper;
export {
  stdin_default as default
};
