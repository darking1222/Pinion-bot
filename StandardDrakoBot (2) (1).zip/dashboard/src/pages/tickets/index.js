import { jsx } from "react/jsx-runtime";
import React from "react";
import TicketsPage from "../../components/tickets/page";
function TicketsPageContainer() {
  return /* @__PURE__ */ jsx(TicketsPage, {});
}
var stdin_default = TicketsPageContainer;
export {
  stdin_default as default
};
